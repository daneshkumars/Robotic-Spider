using NUnit.Framework;
using Robotic_Spider.Controllers;
using Robotic_Spider.Models;
using System.Threading.Tasks;

namespace RoboticSpiderUnitTests
{
    public class Tests
    {
        SpiderController spiderController;
        SpiderModel spiderModel;
        [SetUp]
        public void Setup()
        {
            spiderController = new SpiderController();
            spiderModel = new SpiderModel();
            spiderModel.spiderDirection = Robotic_Spider.Enums.SpiderDirection.LEFT;
            spiderModel.SpiderpositionX = 4;
            spiderModel.SpiderpositionY = 10;
            spiderModel.Walllength = 7;
            spiderModel.Wallbreadth = 15;
            spiderModel.Explore = "FLFLFRFFLF";

        }

        [Test]
        public Task ControlSpider_PassAsync()
        {
           
            spiderController.Control(spiderModel);
            return Task.CompletedTask;
        }
    }
}