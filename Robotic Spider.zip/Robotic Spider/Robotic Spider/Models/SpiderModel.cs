﻿using Robotic_Spider.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Robotic_Spider.Models
{
    public class SpiderModel
    {
        [Required(ErrorMessage = "Enter Spider's current X position")]
        public int SpiderpositionX { get; set; }
        [Required(ErrorMessage = "Enter Spider's current Y position")]
        public int SpiderpositionY { get; set; }
        [Required(ErrorMessage = "Enter Spider's Direction")]
        public SpiderDirection spiderDirection { get; set; }
        [Required(ErrorMessage = "Enter Wall Length")]
        public int Walllength { get; set; }
        [Required(ErrorMessage = "Enter Wall Breadth")]
        public int Wallbreadth { get; set; }
        [Required(ErrorMessage = "Enter Explore Details")]
        public String Explore { get; set; }
    }
}
