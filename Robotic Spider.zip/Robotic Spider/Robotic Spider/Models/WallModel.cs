﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Robotic_Spider.Models
{
    public class WallModel
    {
        public int Walllength { get; set; }
        public int Wallbreadth { get; set; }
    }
}
