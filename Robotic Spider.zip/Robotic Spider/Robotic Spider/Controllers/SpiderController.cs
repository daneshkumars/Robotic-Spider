﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Robotic_Spider.Models;
using Robotic_Spider.Enums;

namespace Robotic_Spider.Controllers
{
    public class SpiderController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ViewResult Control(SpiderModel obj)
        {
            char[] charexplorer = new char[obj.Explore.Length];
            charexplorer = obj.Explore.ToCharArray();
            for (int i =0; i < charexplorer.Length; i++)
            {
                char charexplore = charexplorer[i];
                ControlSpider(obj, charexplore);
            }
            ModelState.Clear();
            return View(obj);
        }
        private void ControlSpider(SpiderModel obj, char explore)
        {
            switch (explore)
            {
                case 'L':
                    if (obj.spiderDirection == SpiderDirection.LEFT)
                    {
                        obj.spiderDirection = SpiderDirection.DOWNWARD;
                    }
                    else if (obj.spiderDirection == SpiderDirection.RIGHT)
                    {
                        obj.spiderDirection = SpiderDirection.UPWARD;
                    }
                    else if (obj.spiderDirection == SpiderDirection.UPWARD)
                    {
                        obj.spiderDirection = SpiderDirection.LEFT;
                    }
                    else
                    { obj.spiderDirection = SpiderDirection.RIGHT; }
                    break;
                case 'R':
                    if (obj.spiderDirection == SpiderDirection.LEFT)
                    {
                        obj.spiderDirection = SpiderDirection.UPWARD;
                    }
                    else if (obj.spiderDirection == SpiderDirection.RIGHT)
                    {
                        obj.spiderDirection = SpiderDirection.DOWNWARD;
                    }
                    else if (obj.spiderDirection == SpiderDirection.UPWARD)
                    {
                        obj.spiderDirection = SpiderDirection.RIGHT;
                    }
                    else
                    { obj.spiderDirection = SpiderDirection.LEFT; }
                    break;
                case 'F':
                    if (obj.spiderDirection == SpiderDirection.LEFT)
                    {
                        obj.SpiderpositionX = obj.SpiderpositionX - 1;
                    }
                    else if (obj.spiderDirection == SpiderDirection.RIGHT)
                    {
                        obj.SpiderpositionX = obj.SpiderpositionX + 1;
                    }
                    else if (obj.spiderDirection == SpiderDirection.UPWARD)
                    {
                        obj.SpiderpositionY = obj.SpiderpositionY + 1;
                    }
                    else
                    { obj.SpiderpositionY = obj.SpiderpositionY - 1; }
                    break;
            }
        }
    }
}
