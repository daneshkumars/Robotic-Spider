﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Robotic_Spider.Enums
{
    public enum SpiderDirection
    {
        LEFT,
        RIGHT,
        UPWARD,
        DOWNWARD
    }
    public enum Explore
    {
        L,
        R,
        F
    }
}
